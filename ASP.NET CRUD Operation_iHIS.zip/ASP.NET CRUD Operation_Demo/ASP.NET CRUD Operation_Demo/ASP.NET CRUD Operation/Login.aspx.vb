﻿Imports System.Data.SqlClient
Imports System.Data

Public Class Login
    Inherits System.Web.UI.Page
    Dim cnn As New SqlConnection("Data Source=DESKTOP-K4167OV;Initial Catalog=NCS_IHIS;Integrated Security=True")
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnSignIn_Click(sender As Object, e As EventArgs) Handles btnSignIn.Click
        Dim cmd As String
        cmd = "SELECT * FROM Users WHERE Email = '" & txtUser.Text & "' AND Password = '" & txtPassword.Text & "'"
        Dim da As New SqlDataAdapter(cmd, cnn)
        Dim ds As New DataSet
        da.Fill(ds)

        If (ds.Tables(0).Rows.Count > 0) Then
            Session("LoginID") = ds.Tables(0).Rows(0)("UserID").ToString()
            Response.Redirect("PatientMaster.aspx")
        Else
            lblMsg.Text = "UserName or Password is incorrect"
            lblMsg.ForeColor = Drawing.Color.Red
        End If

    End Sub
End Class