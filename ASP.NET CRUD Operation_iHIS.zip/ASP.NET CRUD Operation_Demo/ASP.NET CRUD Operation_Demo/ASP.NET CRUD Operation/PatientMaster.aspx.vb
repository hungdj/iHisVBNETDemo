﻿Imports System.Data.SqlClient
Imports System.Data
Public Class PatientMaster
    Inherits System.Web.UI.Page
    Dim cnn As New SqlConnection("Data Source=DESKTOP-K4167OV;Initial Catalog=NCS_IHIS;Integrated Security=True")
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            ResetPatient()
            BindPatients()
        End If
    End Sub
    Protected Sub BindPatients()
        Dim cmd As String = "SELECT * FROM Patients"
        Dim da As New SqlDataAdapter(cmd, cnn)
        Dim ds As New DataSet
        da.Fill(ds)

        GridView1.DataSource = ds.Tables(0)
        GridView1.DataBind()
    End Sub

    Protected Sub ResetPatient()
        txtName.Text = ""
        txtNRIC.Text = ""
        txtDateOfBirthday.Text = Date.Now()
        txtPhoneNumber.Text = ""
        txtAddress.Text = ""
    End Sub

    Protected Sub btnAddPatient_Click(sender As Object, e As EventArgs) Handles btnAddPatient.Click
        Dim cmd As New SqlCommand
        cmd.CommandText = "INSERT INTO Patients(Name, NRIC, DateOfBirth, PhoneNumber, Address) VALUES('" & txtName.Text & "', '" & txtNRIC.Text & "', '" & txtDateOfBirthday.Text & "', '" & txtPhoneNumber.Text & "', '" & txtAddress.Text & "'" & ")"
        cmd.Connection = cnn
        cnn.Open()
        cmd.ExecuteNonQuery()
        cnn.Close()
        ResetPatient()
        BindPatients()
    End Sub

    Private Sub GridView1_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView1.RowCommand
        Dim index As Integer = e.CommandArgument
        Dim cmdname As String = e.CommandName
        Dim pid As Integer = GridView1.Rows(index).Cells(0).Text
        ViewState("PID") = pid

        If e.CommandName = "pedit" Then
            txtName.Text = GridView1.Rows(index).Cells(1).Text
            txtNRIC.Text = GridView1.Rows(index).Cells(2).Text
            txtDateOfBirthday.Text = Date.Parse(GridView1.Rows(index).Cells(3).Text)
            txtPhoneNumber.Text = GridView1.Rows(index).Cells(4).Text
            txtAddress.Text = GridView1.Rows(index).Cells(5).Text
        Else
            Dim cmd As New SqlCommand
            cmd.CommandText = "DELETE FROM Patients WHERE ID = " & pid
            cmd.Connection = cnn
            cnn.Open()
            cmd.ExecuteNonQuery()
            cnn.Close()

            BindPatients()
        End If
    End Sub

    Protected Sub btnSaveChange_Click(sender As Object, e As EventArgs) Handles btnSaveChange.Click
        Dim pid As Integer = ViewState("PID")
        Dim cmd As New SqlCommand
        cmd.CommandText = "UPDATE Patients SET Name = '" & txtName.Text & "', NRIC = '" & txtNRIC.Text & "', DateOfBirth = '" & txtDateOfBirthday.Text _
        & "', PhoneNumber = '" & txtPhoneNumber.Text & "', Address = '" & txtAddress.Text & "' WHERE ID = " & pid
        cmd.Connection = cnn
        cnn.Open()
        cmd.ExecuteNonQuery()
        cnn.Close()

        BindPatients()
    End Sub
End Class